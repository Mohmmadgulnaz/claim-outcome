from fastapi.testclient import TestClient
from app import app

c = TestClient(app)
GOOD = {"payer": "Aetna", "provider": "Dr. Rao", "cpt_code": "99213",
        "diagnosis_code": "M54.5", "billed_amount": 220.0, "patient_age": 45}


def test_ok():
    r = c.post("/predict", json=GOOD)
    assert r.status_code == 200
    assert abs(sum(r.json()["probabilities"].values()) - 1) < 0.01


def test_missing_field():
    bad = {k: v for k, v in GOOD.items() if k != "payer"}
    assert c.post("/predict", json=bad).status_code == 400


def test_text_amount():
    assert c.post("/predict", json={**GOOD, "billed_amount": "abc"}).status_code == 400


def test_unseen_payer_does_not_crash():
    assert c.post("/predict", json={**GOOD, "payer": "NewPayer"}).status_code == 200
