"""Step 4: FastAPI service. Run: uvicorn app:app --reload"""
import joblib
import pandas as pd
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, field_validator

from appeal import get_appeal_guidance  # bonus

app = FastAPI(title="Claim Outcome Predictor")
model = joblib.load("model.joblib")


class Claim(BaseModel):
    payer: str = Field(min_length=1)
    provider: str = Field(min_length=1)
    cpt_code: str = Field(min_length=1)
    diagnosis_code: str = Field(min_length=1)
    billed_amount: float = Field(gt=0)
    patient_age: int = Field(ge=0, le=120)

    @field_validator("cpt_code", mode="before")
    @classmethod
    def cpt_to_str(cls, v):      # allow 99213 (number) as well as "99213"
        return str(v) if isinstance(v, int) else v


@app.exception_handler(RequestValidationError)
async def validation_handler(request: Request, exc: RequestValidationError):
    errors = [{"field": ".".join(str(p) for p in e["loc"][1:]), "problem": e["msg"]}
              for e in exc.errors()]
    return JSONResponse(status_code=400, content={"error": "Invalid request", "details": errors})


@app.post("/predict")
def predict(claim: Claim):
    row = claim.model_dump()
    row["provider"] = row["provider"].replace(" ", "")   # "Dr. Rao" -> "Dr.Rao" (training format)
    X = pd.DataFrame([row])
    proba = model.predict_proba(X)[0]
    probs = {c: round(float(p), 4) for c, p in zip(model.classes_, proba)}
    ordered = {k: probs[k] for k in ["Paid", "Partially_Paid", "Denied"]}
    return {"predicted_status": max(probs, key=probs.get), "probabilities": ordered}


@app.get("/appeal-guidance")
def appeal(denial_reason: str):
    return get_appeal_guidance(denial_reason)
