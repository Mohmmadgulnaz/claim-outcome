"""Bonus: keyword-based retrieval of appeal guidance snippets."""
import re

SNIPPETS = {
    "missing_auth": ("Prior authorization missing. Obtain retro-authorization if the payer allows it, "
                     "attach the clinical notes showing medical necessity, and cite the date of service.",
                     ["auth", "authorization", "precert", "prior"]),
    "eligibility_lapse": ("Coverage inactive on date of service. Verify eligibility history; if the member was "
                          "covered, attach the eligibility printout. Otherwise bill the patient or secondary payer.",
                          ["eligibility", "coverage", "inactive", "lapse", "terminated"]),
    "duplicate_claim": ("Claim flagged as duplicate. Confirm the original claim's status and, if distinct, "
                        "resubmit with the correct modifier (e.g. -25/-76) and a note explaining the difference.",
                        ["duplicate", "dup", "already", "resubmission"]),
    "timely_filing": ("Filed after the payer's deadline. Appeal with proof of timely submission "
                      "(clearinghouse acceptance report, prior rejection dated within the window).",
                      ["timely", "filing", "late", "deadline"]),
    "coding_error": ("CPT/diagnosis mismatch. Review the coding with the provider, correct it, "
                     "and submit a corrected claim.",
                     ["coding", "cpt", "diagnosis", "mismatch", "modifier", "code"]),
    "medical_necessity": ("Service deemed not medically necessary. Attach clinical documentation, "
                          "guideline references and a letter from the provider.",
                          ["necessity", "necessary", "experimental", "medical"]),
    "out_of_network": ("Provider out of network. Check for network-gap or emergency exceptions "
                       "and request a network-adequacy review.",
                       ["network", "out-of-network", "oon"]),
}


def get_appeal_guidance(denial_reason: str) -> dict:
    tokens = set(re.findall(r"[a-z\-]+", denial_reason.lower().replace("_", " ")))
    best, best_score = None, 0
    for key, (text, kws) in SNIPPETS.items():
        score = sum(1 for k in kws if k in tokens) + (3 if key in denial_reason.lower() else 0)
        if score > best_score:
            best, best_score = key, score
    if best is None:
        return {"matched": None, "guidance": "No matching guidance; escalate to a human biller."}
    return {"matched": best, "guidance": SNIPPETS[best][0]}
