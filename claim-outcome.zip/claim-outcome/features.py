"""Leakage-safe feature engineering, packaged as an sklearn transformer.

All statistics are learned in fit() (which only ever sees TRAINING rows) and
merely looked up in transform(), so the test set / new API requests never
influence them.
"""
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin


class ClaimFeatures(BaseEstimator, TransformerMixin):
    def __init__(self, smoothing=10):
        self.smoothing = smoothing  # shrinks rates of rare categories toward the global rate

    def fit(self, X, y):
        X = X.reset_index(drop=True)
        y = pd.Series(np.asarray(y))
        denied = (y == "Denied").astype(float)
        partial = (y == "Partially_Paid").astype(float)
        self.global_deny_ = denied.mean()
        self.global_partial_ = partial.mean()
        self.payer_deny_ = self._rate(X["payer"], denied, self.global_deny_)
        self.provider_deny_ = self._rate(X["provider"], denied, self.global_deny_)
        self.cpt_partial_ = self._rate(X["cpt_code"], partial, self.global_partial_)
        self.cpt_median_bill_ = X.groupby("cpt_code")["billed_amount"].median()
        self.global_median_bill_ = X["billed_amount"].median()
        return self

    def _rate(self, col, target, prior):
        g = pd.DataFrame({"k": col.values, "t": target.values}).groupby("k")["t"].agg(["sum", "count"])
        return (g["sum"] + self.smoothing * prior) / (g["count"] + self.smoothing)

    def transform(self, X):
        X = X.copy().reset_index(drop=True)
        X["payer_denial_rate"] = X["payer"].map(self.payer_deny_).fillna(self.global_deny_)
        X["provider_denial_rate"] = X["provider"].map(self.provider_deny_).fillna(self.global_deny_)
        X["cpt_partial_rate"] = X["cpt_code"].map(self.cpt_partial_).fillna(self.global_partial_)
        med = X["cpt_code"].map(self.cpt_median_bill_).fillna(self.global_median_bill_)
        X["billed_vs_cpt_median"] = X["billed_amount"] / med
        X["is_senior"] = (X["patient_age"] >= 65).astype(int)
        return X
