"""Step 0: simulate ~450 historical claims (~70% Paid / 20% Partially_Paid / 10% Denied)."""
import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
N = 450

payers = ["Aetna", "Cigna", "UnitedHC", "BlueCross"]
providers = ["Dr.Rao", "Dr.Shah", "Dr.Lee", "Dr.Khan", "Dr.Patel"]
cpts = ["99213", "99214", "99215", "99203", "93000"]
diags = ["M54.5", "J06.9", "E11.9", "I10", "K21.9"]

# Hidden "true" tendencies so the model has real signal to learn.
payer_deny = {"Aetna": 0.07, "Cigna": 0.16, "UnitedHC": 0.09, "BlueCross": 0.08}
cpt_partial = {"99213": 0.15, "99214": 0.20, "99215": 0.30, "99203": 0.20, "93000": 0.20}
cpt_base_bill = {"99213": 150, "99214": 220, "99215": 300, "99203": 250, "93000": 80}

rows = []
for i in range(1, N + 1):
    payer = rng.choice(payers, p=[0.35, 0.25, 0.25, 0.15])
    provider = rng.choice(providers)
    cpt = rng.choice(cpts)
    diag = rng.choice(diags)
    billed = round(float(cpt_base_bill[cpt] * rng.lognormal(0, 0.35)), 2)
    age = int(np.clip(rng.normal(48, 16), 18, 90))

    p_deny = payer_deny[payer] + (0.05 if billed > 1.4 * cpt_base_bill[cpt] else 0)
    p_part = cpt_partial[cpt] + (0.05 if age > 65 else 0)
    p_deny, p_part = min(p_deny, 0.5), min(p_part, 0.5)
    p_paid = max(1 - p_deny - p_part, 0.05)
    probs = np.array([p_paid, p_part, p_deny]); probs /= probs.sum()
    status = rng.choice(["Paid", "Partially_Paid", "Denied"], p=probs)
    rows.append((i, payer, provider, cpt, diag, billed, age, status))

df = pd.DataFrame(rows, columns=["id", "payer", "provider", "cpt_code", "diagnosis_code",
                                 "billed_amount", "patient_age", "status"])
df.to_csv("claims.csv", index=False)
print(df.status.value_counts(normalize=True).round(3))
print(f"Saved {len(df)} rows -> claims.csv")
