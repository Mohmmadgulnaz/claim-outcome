"""Steps 1-3: split, engineer features, train, evaluate, save pipeline."""
import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

from features import ClaimFeatures

df = pd.read_csv("claims.csv", dtype={"cpt_code": str})
X = df.drop(columns=["id", "status"])
y = df["status"]

# Step 1: stratified split BEFORE any feature statistics are computed
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42)
print("Train mix:\n", y_train.value_counts(normalize=True).round(3).to_dict())
print("Test mix: \n", y_test.value_counts(normalize=True).round(3).to_dict())

cat_cols = ["payer", "provider", "cpt_code", "diagnosis_code"]
num_cols = ["billed_amount", "patient_age", "payer_denial_rate", "provider_denial_rate",
            "cpt_partial_rate", "billed_vs_cpt_median", "is_senior"]

pre = ColumnTransformer([
    ("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols),
    ("num", "passthrough", num_cols),
])

# Step 2: preprocessing + model bundled in ONE pipeline
pipe = Pipeline([
    ("features", ClaimFeatures()),
    ("pre", pre),
    ("model", RandomForestClassifier(
        n_estimators=300, min_samples_leaf=3,
        class_weight="balanced_subsample", random_state=42, n_jobs=-1)),
])
pipe.fit(X_train, y_train)          # fit() only ever sees training rows -> no leakage

# Step 3: evaluate on untouched test set
pred = pipe.predict(X_test)
labels = ["Paid", "Partially_Paid", "Denied"]
report = classification_report(y_test, pred, labels=labels, digits=3, zero_division=0)
cm = pd.DataFrame(confusion_matrix(y_test, pred, labels=labels),
                  index=[f"actual_{l}" for l in labels],
                  columns=[f"pred_{l}" for l in labels])
print("\n=== Classification report (test set) ===\n", report)
print("=== Confusion matrix ===\n", cm)

with open("metrics.txt", "w") as f:
    f.write(report + "\n" + cm.to_string() + "\n")

joblib.dump(pipe, "model.joblib")
print("\nSaved model.joblib and metrics.txt")
